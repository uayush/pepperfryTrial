 package Tests;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.Base.BaseClass;
import com.PageObjects.HomePage;
import com.PageObjects.Register;
import com.Utils.TestUtil;

import utils.ExtentReports.ExtentTestManager;

public class RegisterTest extends BaseClass {
	
	Register register = new Register();;
	HomePage homepage;
	private Logger log = Logger.getLogger(RegisterTest.class.getName());
	

	
	
	@Test
	public void registration() {
		ExtentTestManager.startTest("Registration", "Sign up to the Application .");
		log.info("Trying to register");
		register.clickRegister();
		
		register.HandleAlert();
		log.info("Closing the Ad");
		register.registrationDetails(prop.getProperty("email"), prop.getProperty("mobile"),
				prop.getProperty("fname"), prop.getProperty("lname"), prop.getProperty("pwd"));
		log.info("New user Created");
		if (driver.getPageSource().contains("Logout ")) {
			Assert.assertTrue(true, "Valid Registration");
			log.info("Sign up successfull for the user  :" + (prop.getProperty("fname")));
		}

	}

}
