package utils.ExcelFileReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadWrite {
	private static XSSFWorkbook ExcelWBook;
	private static XSSFSheet ExcelWSheet;
	private static XSSFCell Cell;
	public InputStream oFileReader;
	public Workbook oExcel;
	XSSFWorkbook workbook;
 
	// This method is to set the File path and to open the Excel file
	// Pass Excel Path and SheetName as Arguments to this method
	public static void setExcelFile(String Path, String SheetName) throws Exception {
		FileInputStream ExcelFile = new FileInputStream(Path);
		ExcelWBook = new XSSFWorkbook(ExcelFile);
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
	}

	// This method is to read the test data from the Excel cell
	// In this we are passing parameters/arguments as Row Num and Col Num
	public static String getCellData(int RowNum, int ColNum) throws Exception {
		Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
		String CellData = "";
		// Cell.get
		if (Cell == null) { // cell was never written to

		} else {
			CellData = Cell.getStringCellValue();

		}
		return CellData;
	}

	public static String getCellDataformate(int RowNum, int ColNum) throws Exception {
		Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
		String CellData = "";
		// Cell.get
		if (Cell == null) { // cell was never written to

		} else {
			DataFormatter formatter = new DataFormatter();
			CellData = formatter.formatCellValue(ExcelWSheet.getRow(RowNum).getCell(ColNum));
			// CellData= Cell.getStringCellValue();

		}
		return CellData;
	}

	// writing to the cell object
	public static void setCellData(String data, int RowNum, int ColNum) throws Exception {
		try {
			XSSFRow Row = ExcelWSheet.getRow(RowNum);
			Cell = Row.getCell(ColNum);
			if (Cell == null) { // Cell was never used
				Cell = Row.createCell(ColNum);
				Cell.setCellValue(data);
			} else {
				Cell.setCellValue(data);
			}
		} catch (Exception e) {
			throw (e);
		}
	}

	public void writeExcelData(Map<String, Object[]> data, String s) throws IOException {

		String FileName = "C:\\Eclipse\\PepperFry_Framework\\resources\\ProductSorteddata.xlsx";
		if (new File(FileName).exists()) {
			try {
				// throw new Exception("File already exists");
				oFileReader = new FileInputStream(FileName);
				oExcel = WorkbookFactory.create(oFileReader);
				Sheet oSheet;
				oSheet = oExcel.getSheet(s);
				if (oSheet == null) {
					Sheet sheet = oExcel.createSheet(s);
					Set<String> keyset = data.keySet();
					int rownum = 0;
					for (String key : keyset) {
						// this creates a new row in the sheet
						Row row = sheet.createRow(rownum++);
						Object[] objArr = data.get(key);
						int cellnum = 0;
						for (Object obj : objArr) {
							// this line creates a cell in the next column of that row
							Cell cell = row.createCell(cellnum++);
							if (obj instanceof String)
								cell.setCellValue((String) obj);
							else if (obj instanceof Integer)
								cell.setCellValue((Integer) obj);
						}
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				// this Writes the workbook gfgcontribute
				FileOutputStream out = new FileOutputStream(FileName);
				oExcel.write(out);
				out.close();
				System.out.println("ProductSorteddata.xlsx written successfully on disk.");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// Create a blank sheet
		else {
			workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(s);
			Set<String> keyset = data.keySet();
			int rownum = 0;
			for (String key : keyset) {
				// this creates a new row in the sheet
				Row row = sheet.createRow(rownum++);
				Object[] objArr = data.get(key);
				int cellnum = 0;
				for (Object obj : objArr) {
					// this line creates a cell in the next column of that row
					Cell cell = row.createCell(cellnum++);
					if (obj instanceof String)
						cell.setCellValue((String) obj);
					else if (obj instanceof Integer)
						cell.setCellValue((Integer) obj);
				}
			}

			try {
				// this Writes the workbook gfgcontribute
				FileOutputStream out = new FileOutputStream(
						new File("C:\\\\Eclipse\\\\PepperFry_Framework\\\\resources\\\\ProductSorteddata.xlsx"));
				workbook.write(out);
				out.close();
				System.out.println("ProductSorteddata.xlsx written successfully on disk.");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static void saveFile(String Path) throws IOException {
		try {
			FileOutputStream fileOut = new FileOutputStream(Path);
			ExcelWBook.write(fileOut);
			fileOut.close();
		} catch (IOException e) {
			throw (e);
		}
	}

}
