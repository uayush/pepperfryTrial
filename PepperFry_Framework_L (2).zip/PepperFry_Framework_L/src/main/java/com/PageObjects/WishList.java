package com.PageObjects;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ddf.EscherColorRef.SysIndexProcedure;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.Base.GenericUtil;

public class WishList extends GenericUtil {

	/** Web Elements */
	By searchbox = By.id("search");
	By searchbutton = By.id("searchButton");
	By items1 = By.xpath("//div[@class='clip-crd-10x11 pf-white srch-rslt-bxwrpr']");
	By itemsName1 = By.xpath("//div[@class='pf-col xs-12']/h2/a");
	By wishlisticon1 = By.xpath("//a[@class='clip-heart-icn pf-right']");
	By wishlisticonMain = By.xpath("//*[@id=\"headerUserArea\"]/div[2]/div/div[3]/div[2]/a");
	By removebutton = By.xpath(
			"//div[@class='item_card_wrapper']/div/div/div[@class='item_details']/div[@class='item_cta']/div/a[@class='deleteicon']");
	By addedWishListName = By.xpath("//div[@class='item_details']/p[@class='item_title pf-bold-txt']/a");

	By wishListItems = By.xpath("//div[@class='item_details']/p/a");

	static List<String> productName = new ArrayList<String>();

	public void AddToWishList(String itemType) throws InterruptedException

	{
		Thread.sleep(2000);
		setText(searchbox, itemType);
		click(searchbutton);
		Thread.sleep(2000);

		List<WebElement> listOfProductList = driver.findElements(items1);
		List<WebElement> listOfProductName = driver.findElements(itemsName1);
		List<WebElement> wishlistIcon = driver.findElements(wishlisticon1);

		Thread.sleep(2000);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

		for (int i = 0; i < 5; i++) {

			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", listOfProductList.get(i));
			String pName = listOfProductName.get(i).getText();
			wait.until(ExpectedConditions.elementToBeClickable(wishlistIcon.get(i)));

			Thread.sleep(1000);
			wishlistIcon.get(i).click();
			productName.add(pName);

			System.out.println("Clicking on ============================================");
			System.out.println(pName);
		}

	}

	public void removeWishList() {

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		click(wishlisticonMain);

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

		List<WebElement> wishList = driver.findElements(removebutton);

		// ----------------validation of wishList

		List<WebElement> addedWishListElementName = driver.findElements(addedWishListName);

		int i = 0;
		for (WebElement ele : wishList) {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
			System.out.println(addedWishListElementName.get(i).getText());
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			ele.click();
			i++;
		}

	}

	public void validateWishList() {

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		click(wishlisticonMain);
		List<WebElement> wishItems = driver.findElements(wishListItems);

		List<String> wishListName = new ArrayList<String>();
		for (WebElement webElement : wishItems) {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", webElement);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}

			String name = webElement.getText();
			if (name.endsWith("...")) {
				name = name.substring(0, name.length() - 3);

			}
			name = name.split(" ")[0];
			// name = name.split("by")[0];
			System.out.println(name);
			wishListName.add(name);
		}
		System.out.println(wishListName);
		for (String p : productName) {
			System.out.println(p.split(" ")[0]);
			Assert.assertTrue(wishListName.contains(p.split(" ")[0]), "Item not Found: " + p);
		}

	}
}
