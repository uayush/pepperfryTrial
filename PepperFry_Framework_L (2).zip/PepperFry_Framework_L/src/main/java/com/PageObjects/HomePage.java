package com.PageObjects;

import com.Base.BaseClass;

public class HomePage extends BaseClass{
	

}
